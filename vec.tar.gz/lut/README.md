



## Benchmark



```text
Benchmark_LookupSubrangeNaive-8          9316396                  129.1 ns/op
Benchmark_LookupSubrange_Neon-8          159349155                7.544 ns/op
Benchmark_Lookup_Naive-8                 9197492                  130.4 ns/op
Benchmark_Lookup_Neon-8                  35035856                 33.98 ns/op
```