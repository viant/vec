package bitwise

import (
	"golang.org/x/sys/cpu"
	"testing"
)

func BenchmarkAnd_S_Arm64SVE(b *testing.B) {
	if !cpu.ARM64.HasSVE {
		b.Skip("ARM64.SVE not supported")
	}
	out := make([]uint64, len(op1S))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		Uint64s(out).AndSVE(op1S, op2S)
	}
}

func BenchmarkAnd_M_Arm64SVE(b *testing.B) {
	if !cpu.ARM64.HasSVE {
		b.Skip("ARM64.SVE not supported")
	}
	out := make([]uint64, len(op1M))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		Uint64s(out).AndSVE(op1M, op2M)
	}
}

func BenchmarkAnd_XL_Arm64SVE(b *testing.B) {
	if !cpu.ARM64.HasSVE {
		b.Skip("ARM64.SVE not supported")
	}
	out := make([]uint64, len(op2XL))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		Uint64s(out).AndSVE(op1XL, op2XL)
	}
}

func BenchmarkAnd_S_Arm64Neon(b *testing.B) {
	if !cpu.ARM64.HasASIMD {
		b.Skip("ARM64.SIMD not supported")
	}
	out := make([]uint64, len(op1S))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		Uint64s(out).AndNeon(op1S, op2S)
	}
}

func BenchmarkAnd_M_Arm64Neon(b *testing.B) {
	if !cpu.ARM64.HasASIMD {
		b.Skip("ARM64.SIMD not supported")
	}
	out := make([]uint64, len(op1M))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		Uint64s(out).AndNeon(op1M, op2M)
	}
}

func BenchmarkAnd_XL_Arm64Neon(b *testing.B) {
	if !cpu.ARM64.HasASIMD {
		b.Skip("ARM64.SIMD not supported")
	}
	out := make([]uint64, len(op2XL))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		Uint64s(out).AndNeon(op1XL, op2XL)
	}
}

func BenchmarkOr_M_V3_Neon(b *testing.B) {
	if !cpu.ARM64.HasASIMD {
		b.Skip("ARM64.SVE not supported")
	}
	out := make([]uint64, len(op1M))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		Uint64s(out).OrV3Neon(op1M, op2M, op3M)
	}
}


func BenchmarkOr_M_V4_Neon(b *testing.B) {
	if !cpu.ARM64.HasASIMD {
		b.Skip("ARM64.SVE not supported")
	}
	out := make([]uint64, len(op1M))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		Uint64s(out).OrV4Neon(op1M, op2M, op3M, op4M)
	}
}

func BenchmarkOr_M_V5_Neon(b *testing.B) {
	if !cpu.ARM64.HasASIMD {
		b.Skip("ARM64.SVE not supported")
	}
	out := make([]uint64, len(op1M))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		Uint64s(out).OrV5Neon(op1M, op2M, op3M, op4M, op5M)
	}
}


func BenchmarkOr_M_V3_SVE(b *testing.B) {
	if !cpu.ARM64.HasSVE {
		b.Skip("ARM64.SVE not supported")
	}
	out := make([]uint64, len(op1M))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		Uint64s(out).OrV3SVE(op1M, op2M, op3M)
	}
}


func BenchmarkOr_M_V4_SVE(b *testing.B) {
	if !cpu.ARM64.HasSVE {
		b.Skip("ARM64.SVE not supported")
	}
	out := make([]uint64, len(op1M))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		Uint64s(out).OrV4SVE(op1M, op2M, op3M, op4M)
	}
}



func BenchmarkOr_M_V5_SVE(b *testing.B) {
	if !cpu.ARM64.HasSVE {
		b.Skip("ARM64.SVE not supported")
	}
	out := make([]uint64, len(op1M))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		Uint64s(out).OrV5SVE(op1M, op2M, op3M, op4M, op5M)
	}
}


func BenchmarkOr_M_V6_SVE(b *testing.B) {
	if !cpu.ARM64.HasSVE {
		b.Skip("ARM64.SVE not supported")
	}
	out := make([]uint64, len(op1M))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		Uint64s(out).OrV6SVE(op1M, op2M, op3M, op4M, op5M, op6M)
	}
}



func BenchmarkOr_M_V9_SVE(b *testing.B) {
	if !cpu.ARM64.HasSVE {
		b.Skip("ARM64.SVE not supported")
	}
	out := make([]uint64, len(op1M))
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		Uint64s(out).OrV9SVE(op1M, op2M, op3M, op4M, op5M, op6M, op7M, op8M, op9M)
	}
}
