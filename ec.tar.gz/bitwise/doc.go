//Package bitwise defines vectorized bitwise operations
package bitwise
