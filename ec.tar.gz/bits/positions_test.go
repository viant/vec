package bits

import (
	"github.com/stretchr/testify/assert"
	"math/rand"
	"testing"
	"time"
)

var benchInput = uint64(0xf55555555555555f)
var out Positions
var rnd = rand.New(rand.NewSource(time.Now().UnixNano()))

func TestPositions(t *testing.T) {
	var expectedOut, actualOut Positions

	input := rnd.Uint64()
	expectedCount := expectedOut.populate(input)
	actualCount := actualOut.Populate(input)
	assert.EqualValues(t, expectedOut[0:expectedCount], actualOut[0:actualCount], "TestPositions")
}

func BenchmarkPositionsNaive(b *testing.B) {
	for n := 0; n < b.N; n++ {
		out.populate(benchInput)
	}
}

func BenchmarkPositions(b *testing.B) {
	for n := 0; n < b.N; n++ {
		out.Populate(benchInput)
	}
}
