package main

import (
	"bufio"
	"bytes"
	"fmt"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"strconv"
	"strings"
)

func goArm(location string, matchingFragments ...string) error {
	cmd := exec.Command("go", "tool", "objdump", location)
	output, err := cmd.CombinedOutput()
	if err != nil {
		return err
	}
	scanner := bufio.NewScanner(bytes.NewReader(output))
	outer := &strings.Builder{}
	builder := &strings.Builder{}
	funName := ""
	var ok bool
	for scanner.Scan() {
		line := scanner.Text()
		if strings.Contains(line, "TEXT") {
			if builder.Len() > 0 {
				 if hasAllMatches(matchingFragments, funName) {
					outer.WriteString(builder.String())
				}
			}
			builder = &strings.Builder{}
			funName, ok = addSignature(line, builder)
			if !ok {
				builder.WriteString(line)
			}
			continue
		}
		idx := strings.Index(line, "0x")
		if idx != -1 {
			op := strings.TrimSpace(line[idx+6:])
			spaceIdx := strings.Index(op, "\t")
			if spaceIdx == -1 {
				spaceIdx = strings.Index(op, " ")
			}
			asm := strings.TrimSpace(op[spaceIdx+1:])
			op = strings.TrimSpace(op[:spaceIdx])
			instruction := fmt.Sprintf("WORD $0x%v //%v\n", op, asm)
			builder.WriteString(instruction)
			continue
		}
		builder.WriteString(line)
	}

	fmt.Printf(outer.String())
	return nil
}

func hasAllMatches(matchingFragments []string, funName string) bool {
	matched := true
	for _, mustMatch := range matchingFragments {
		if !strings.Contains(funName, mustMatch) {
			matched = false
		}
	}
	return matched
}

func addSignature(line string, builder *strings.Builder) (string, bool) {
	zIndex := strings.Index(line, "Z")
	pIndex := strings.Index(line, "P")
	if zIndex == -1 || pIndex == -1 {
		return "", false
	}
	name := line[zIndex+1 : pIndex]
	sig := line[pIndex:]
	argsEst := strings.Count(string(sig), "S")
	isDigit := func(b byte) bool {
		return b >= '0' && b <= '9'
	}
	if isDigit(name[0]) {
		name = name[1:]
	}
	if isDigit(name[0]) {
		name = name[1:]
	}
	vCount := 2
	if idx := strings.Index(name, "v"); idx != -1 {
		if v, err := strconv.Atoi(name[idx+1 : idx+2]); err == nil {
			vCount = v
		}
	}
	builder.WriteString(fmt.Sprintf("\n\nTEXT ·_%v(SB), $0-%v\nMOVD out+0(FP),  R0\n", name, (1+argsEst)*8))
	i := 1
	for ; i <= vCount; i++ {
		builder.WriteString(fmt.Sprintf("MOVD v%v+%v(FP), R%v\n", i, (i)*8, i))
	}
	builder.WriteString(fmt.Sprintf("MOVD size+%v(FP), R%v\n", (i)*8, i))
	return fmt.Sprintf("_%v", name), true
}

func main() {
	name := "bitwise_arm64.o"
	cwd, _ := os.Getwd()
	basePath := filepath.Join(cwd, "bitwise/cpp")
	goArm(path.Join(basePath, name), "_or_", "v9")
}
