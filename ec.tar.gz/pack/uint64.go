package pack

type Uint64 uint64
