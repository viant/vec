//Package lut defines vectorized lookup operations
package lut
